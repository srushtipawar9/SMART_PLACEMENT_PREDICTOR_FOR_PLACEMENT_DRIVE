from flask import Flask, render_template, request, redirect, session
import csv, os, fitz, re, joblib
import mysql.connector
import pandas as pd

app = Flask(__name__)
app.secret_key = "your_super-secret-key_here"  

df = pd.read_csv('submissions.csv')  # make sure this file exists

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text.lower()

def extract_skills(text):
    skill_keywords = ['python', 'java', 'html', 'css', 'machine learning', 'sql', 'flask', 'dsa', 'javascript', 'excel', 'react', 'oop']
    return ', '.join([skill for skill in skill_keywords if skill in text])

def extract_experience(text):
    match = re.search(r'(\d+)\+?\s+years? of experience', text)
    return match.group(1) if match else "0"

model = joblib.load('model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/student-form')
def student_form():
    return render_template('student-form.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        
       
        # Get form data
        data = {
            'name': request.form['name'],
            'skills': request.form['skills'],
            'cgpa': float(request.form['cgpa']),
            'salary': float(request.form['salary']),
            'date': request.form['date'],
            'time': request.form['time'],
            'shift': request.form['shift'],
            'attended': request.form['attended'],
            'work_duration': int(request.form['work_duration']),
            'company': request.form['company'],
        }

        
        shift_value = 0 if data['shift'].lower() == 'day' else 1
        attended_value = 1 if data['attended'].lower() == 'yes' else 0

        input_data = [[
            data['cgpa'],
            data['salary'],
            attended_value,
            shift_value,
            data['work_duration']
        ]]

        prob = model.predict_proba(input_data)[0][1]
        percent = round(prob * 100, 2)

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="placement_db"
        )
        cursor = conn.cursor()

        sql = """
        INSERT INTO students
        (name, skills, cgpa, salary, date, time, shift, attended, work_duration, company)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['name'], data['skills'], data['cgpa'], data['salary'], data['date'],
            data['time'], data['shift'], data['attended'],
            data['work_duration'], data['company']
        )

        cursor.execute(sql, values)
        conn.commit()

        with open('submissions.csv', 'a', newline='') as file:
           csv_writer = csv.writer(file)
           csv_writer.writerow([
              data['name'], data['skills'], data['cgpa'], data['salary'],
              data['date'], data['time'], data['shift'], data['attended'],
             data['work_duration'], data['company']
           ])
        cursor.close()
        conn.close()


        return f"""
        <h2>🎯 Placement Prediction Result</h2>
        <p>Thank you, <strong>{data['name']}</strong>!</p>
        <p>You have a <strong>{percent}%</strong> chance of getting placed in <strong>{data['company']}</strong>.</p>
        <br><a href="/">Go Back</a>
        """

@app.route("/admin", methods=["GET"])
def admin_login_page():
    return render_template("admin.html")  # this shows the login form


@app.route("/admin-login", methods=["POST"])
def handle_admin_login():
    username = request.form["username"]
    password = request.form["password"]

    if username == "srushti" and password == "1234":
        session["admin"] = True
        return redirect("/admin-dashboard")  # ✅ fixed route
    else:
        return "<h3>❌ Wrong login. <a href='/admin'>Try again</a></h3>"


@app.route("/admin-dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/admin")

    with open('submissions.csv', 'r') as f:
        reader = csv.reader(f)
        rows = list(reader)

    if rows and rows[0][0].lower() == 'name':
        rows = rows[1:]  # remove header

    cgpa_list = [float(row[2]) for row in rows if row[2]]
    salary_list = [float(row[3]) for row in rows if row[3]]
    attended_list = [row[7].lower() if row[7] else '' for row in rows]

    return render_template("admin-dashboard.html",
                           students=rows,
                           cgpa_list=cgpa_list,
                           salary_list=salary_list,
                           attended_list=attended_list)

if __name__ == '__main__':
    app.run(debug=True)
