<?php

 $username ="username";
 $password ="password";

	//Database connection
	$conn = new mysqli('localhost','root','','placement');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("admin login Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into shruu(username, password) values(?,?)");
		$stmt->bind_param("ss", $username, $password);
		$stmt
		->close();
		$conn->close();

	}
?>
