 <?php
$name = $_POST['name'];
$skills = $_POST['skills'];
$cgpa = $_POST['cgpa'];
$salary = $_POST['salary'];
$date = $_POST['date'];
$time = $_POST['time'];
$shift =$_POST['shift'];
$attended = $_POST['attended'];
$work_duration = $_POST['work_duration'];
$company = $_POST['company'];

$conn = new mysqli('localhost','root','','placement_db');
 mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

	if($conn->connect_error){
		echo "$conn->connect_error";
		die("unsuccessful: ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into students(name, skills, cgpa, salary, date, time, shift, attended, work_duration, company) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssddssssis", $name, $skills, $cgpa, $salary, $date, $time, $shift, $attended, $work_duration, $company);
		$execval = $stmt->execute();
		echo $execval;
		echo "successful..";
		$stmt->close();
		$conn->close();

	}
     // Save to CSV file
    $file = fopen("submissions.csv", "a");  // 'a' = append mode
    fputcsv($file, [$name, $skills, $cgpa, $salary, $date, $time, $shift, $attended, $work_duration, $company]);
     fclose($file);
     echo "Successful: Saved to Database and CSV.";


?> 
