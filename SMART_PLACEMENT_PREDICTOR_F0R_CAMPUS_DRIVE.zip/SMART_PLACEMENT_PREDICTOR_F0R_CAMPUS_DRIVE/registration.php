<?php
// register.php
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

// Database connection
$host = 'localhost';
$db = 'placement_system';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(['message' => 'Connection failed: ' . $conn->connect_error]));
}

$name = $conn->real_escape_string($input['name']);
$email = $conn->real_escape_string($input['email']);
$password = password_hash($input['password'], PASSWORD_BCRYPT);
$salary = $conn->real_escape_string($input['salary']);
$skills = $conn->real_escape_string($input['skills']);
$experience = $conn->real_escape_string($input['experience']);

$sql = "INSERT INTO students (name, email, password, salary_expectation, skills, experience)
        VALUES ('$name', '$email', '$password', '$salary', '$skills', '$experience')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['message' => 'Student registered successfully']);
} else {
    echo json_encode(['message' => 'Error: ' . $conn->error]);
}

$conn->close();
?>
