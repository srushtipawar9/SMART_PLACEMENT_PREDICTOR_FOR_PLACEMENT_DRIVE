<?php
// find_placements.php
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

// Database connection
$host = 'localhost';
$db = 'placement_system';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(['message' => 'Connection failed: ' . $conn->connect_error]));
}

$salary_min = $conn->real_escape_string($input['salary_min']);
$salary_max = $conn->real_escape_string($input['salary_max']);
$skills = $conn->real_escape_string($input['skills']);

$sql = "SELECT * FROM companies WHERE salary_range_start >= '$salary_min' 
        AND salary_range_end <= '$salary_max' 
        AND skills_required LIKE '%$skills%'";

$result = $conn->query($sql);

$companies = [];
while ($row = $result->fetch_assoc()) {
    $companies[] = $row;
}

echo json_encode($companies);

$conn->close();
?>
