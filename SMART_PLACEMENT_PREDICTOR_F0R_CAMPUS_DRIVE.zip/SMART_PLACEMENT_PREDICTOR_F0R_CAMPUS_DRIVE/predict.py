import pandas as pd
import joblib

# Load model
model = joblib.load('model.pkl')

# Load data
df = pd.read_csv('submissions.csv')

# Rename columns correctly according to CSV headers
df.rename(columns={
    'CGPA': 'cgpa',
    'Expected Salary': 'salary',
    'Attended': 'attended',           # map 'Attended' to lowercase for consistency
    'preferred-Shift': 'shift',       # fix hyphen here
    'how many year do you want work': 'work_duration'
}, inplace=True)

print("Columns after rename:", df.columns.tolist())

# Get last row as DataFrame
last_row = df.tail(1)

# Prepare features
X = last_row[['cgpa', 'salary', 'attended', 'shift', 'work_duration']].copy()

# Map categorical to numeric
X['attended'] = X['attended'].map({'Yes': 1, 'No': 0})
X['shift'] = X['shift'].map({'Day': 0, 'Night': 1})

X.fillna(0, inplace=True)

# Predict
prediction = model.predict(X)[0]

# Update placed column
df.at[df.index[-1], 'placed'] = 'yes' if prediction == 1 else 'no'

df.to_csv('submissions.csv', index=False)

print(f"Prediction: {'yes' if prediction == 1 else 'no'} saved to CSV")
