import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib

# Step 1: Load data
df = pd.read_csv('submissions.csv')

# Step 2: Rename for easy access
df.rename(columns={
    'CGPA': float(cgpa),
    'Expected Salary': float(salary),
    'preferred-Shift': int(shift),
    'how many year do you want work': int(work_duration),
    'preferred company': int(company)
}, inplace=True)

# Step 3: Clean and encode data
df['Attended'] = df['Attended'].map({'Yes': 1, 'No': 0})
df['shift'] = df['shift'].map({'Day': 0, 'Night': 1})
df['placed'] = df['placed'].str.lower().map({'yes': 1, 'no': 0})

# Step 4: Drop rows with missing data
df.dropna(inplace=True)

# Step 5: Visualizations for understanding

# Placed vs Not Placed
plt.figure(figsize=(5, 4))
sns.countplot(x='placed', data=df)
plt.title("Placement Distribution")
plt.xticks([0, 1], ['Not Placed', 'Placed'])
plt.savefig('graph_placed.png')
plt.close()

# Attended vs Not Attended
plt.figure(figsize=(5, 4))
sns.countplot(x='Attended', data=df)
plt.title("Interview Attendance")
plt.xticks([0, 1], ['No', 'Yes'])
plt.savefig('graph_attended.png')
plt.close()

# Correlation heatmap (only numeric columns)
plt.figure(figsize=(7, 6))
numeric_df = df.select_dtypes(include=['number'])
sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm')
plt.title("Feature Correlation")
plt.savefig('correlation_heatmap.png')
plt.close()

# Step 6: Define features and target
X = df[['cgpa', 'salary', 'Attended', 'shift', 'work_duration']]
y = df['placed']

# Step 7: Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Step 8: Model training
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 9: Evaluation
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"✅ Model Accuracy: {acc:.2f}")
print("\n📊 Classification Report:\n", classification_report(y_test, y_pred))

# Confusion matrix
plt.figure(figsize=(5, 4))
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap='Greens')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.savefig('confusion_matrix.png')
plt.close()

# Step 10: Feature importance
feat_importance = pd.Series(model.feature_importances_, index=X.columns)
feat_importance.sort_values().plot(kind='barh', title='Feature Importance', figsize=(6, 4))
plt.xlabel('Importance Score')
plt.tight_layout()
plt.savefig('feature_importance.png')
plt.close()

# Step 11: Save model
joblib.dump(model, 'model.pkl')
print("💾 Model saved as model.pkl")

# Optional: Predict for a sample
sample_input = [[8.0, 6.5, 1, 0, 2]]  # cgpa, salary, attended, shift, work_duration
prob = model.predict_proba(sample_input)[0][1]
print(f"🎯 Sample Prediction: Placement chance = {prob * 100:.2f}%")
